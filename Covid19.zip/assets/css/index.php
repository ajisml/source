<?php 
header('location:https://kazepay.com/');
 ?>