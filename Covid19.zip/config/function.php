<!-- Setting -->
<?php 
defined("BASEPATH") or exit(header('location:https://kazepay.com/'));
$baseurl = "http://localhost:444/covid19/";
function covid19($data){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
 ?>
<!-- End Setting KazePay.com -->